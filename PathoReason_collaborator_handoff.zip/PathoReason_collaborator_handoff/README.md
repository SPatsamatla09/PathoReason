# PathoReason Collaborator Handoff

This archive contains existing experimental outputs only.
No new model inference or API calls were performed to create it.

## Important field semantics

### MHIST masking
- baseline.label / baseline.confidence:
  prediction on the original unmasked image
- parsed.label / parsed.confidence:
  prediction after the specified masking intervention
- arm:
  masking arm (e.g. cited/control/struct)
- occlusion:
  masking operation
- masked_cells:
  grid cells removed/occluded when applicable

Do NOT interpret confidence as a calibrated class probability unless
the relevant model/output explicitly defines it that way.

### PCam PLIP masking
Each record is one masking intervention.
- class_probabilities.tumor:
  tumor probability after masking
- class_probabilities.normal:
  normal probability after masking
- arm + occlusion:
  intervention condition

### MHIST PLIP zero-shot
- metadata.class_probabilities.HP
- metadata.class_probabilities.SSA

These are continuous class probabilities suitable for ROC/AUROC analysis.

## Reproducibility principle

Raw outputs are retained rather than converting ambiguous fields into
invented probability columns. Derived analyses should document their
exact transformation from these source fields.
